print("Ingresa tus numeros para resolver la suma")

num1 = int (input())
num2 = int (input())
num3 = int (input())
resultado = num1 + num2 + num3
print("El resultado de " , num1 , "+" , num2 , "+", num3 ,"es igual a :" , resultado)

print("Ingresa tus numeros para resolver la resta")
num1 = int (input())
num2 = int (input())
num3 = int (input())
resultado = num1 - num2 - num3
print("El resultado de " , num1 , "-" , num2 , "-", num3 ,"es igual a :" , resultado)

print("Ingresa tus numeros para resolver la multiplicacion")
num1 = int (input())
num2 = int (input())
num3 = int (input())
resultado = num1 * num2 * num3
print("El resultado de " , num1 , "*" , num2 , "*", num3 ,"es igual a :" , resultado)

print("Ingresa tus numeros para resolver la divicion")
num1 = int (input())
num2 = int (input())
num3 = int (input())
resultado = num1 / num2 / num3
print("El resultado de " , num1 , "/" , num2 , "/", num3 ,"es igual a :" , resultado)